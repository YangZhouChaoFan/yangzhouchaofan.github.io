function showLoginForm(){
    event.stopPropagation();
    $(".login-form").show();
}

function hideLoginForm(){
    $(".login-form").hide();
}